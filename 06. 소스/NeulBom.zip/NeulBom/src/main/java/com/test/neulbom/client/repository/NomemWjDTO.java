package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class NomemWjDTO {
	private String pname;
	private String ptel;
}

package com.test.neulbom.admin.board.repository;

import lombok.Data;

@Data
public class FoodDTO {

	String food_seq;
	String displayed_seq;
	String food_date;
	String content;
	String read;
	String title;

}

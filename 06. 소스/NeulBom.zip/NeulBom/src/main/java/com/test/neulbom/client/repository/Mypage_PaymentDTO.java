package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class Mypage_PaymentDTO {
	private String pay_seq;
	private String resi_seq;
	private String ispay;
	private String pay_date;
	private String resi_name;
	private String pro_name;
	private String pro_id;
	private String tel;
	private String email;
	private String relation;
	private String resi_id;
}

package com.test.neulbom.admin.repository;

import lombok.Data;

@Data
public class ResiDTO {
	private String resi_seq;
	private String id;
	private String pw;
	private String name;
	private String ssn;
	private String tel;
	private String email;
	private String detail;
	private String address;
	private String lv;
}

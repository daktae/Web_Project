package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class UserWjDTO {
	private String pseq;
	private String pname;
	private String pid;
	private String ppw;
	private String pssn;
	private String ptel;
	private String pemail;
	private String rela;
	private String padr;
	private String plv;
	private String rid;
	private String rseq;
	
	
}

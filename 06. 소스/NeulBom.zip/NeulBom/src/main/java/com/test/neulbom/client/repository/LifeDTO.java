package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class LifeDTO {
	private String life_seq;
	private String title;
	private String content;
	private String read;
	private String life_date;
	private String rnum;
}

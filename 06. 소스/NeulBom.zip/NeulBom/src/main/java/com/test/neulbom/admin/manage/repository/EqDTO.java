package com.test.neulbom.admin.manage.repository;

import lombok.Data;

@Data
public class EqDTO {
	private String eq_seq;
	private String name;
	private int quantity;
}

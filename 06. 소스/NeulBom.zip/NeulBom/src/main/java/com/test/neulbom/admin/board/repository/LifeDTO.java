package com.test.neulbom.admin.board.repository;

import lombok.Data;

@Data
public class LifeDTO {
	
	String life_seq;
	String displayed_seq;
	String title;
	String content;
	String read;
	String life_date;

}

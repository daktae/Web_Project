package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class Life_DetailDTO {
	private String life_seq;
	private String title;
	private String content;
	private String read;
	private String life_date;
}

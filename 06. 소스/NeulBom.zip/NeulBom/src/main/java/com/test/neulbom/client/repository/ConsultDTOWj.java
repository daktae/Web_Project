package com.test.neulbom.client.repository;

import lombok.Data;

@Data

public class ConsultDTOWj {
	private String con_seq;
	private String title;
	private String content;
	private String con_date;
	private String isreply;
	private String nomem_seq;
	private String name;
	private String retitle;
	private String recontent;
	private String rnum;
}

package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class Food_DetailDTO {
	private String food_seq;
	private String food_date;
	private String content;
	private String read;
	private String title;
	
}

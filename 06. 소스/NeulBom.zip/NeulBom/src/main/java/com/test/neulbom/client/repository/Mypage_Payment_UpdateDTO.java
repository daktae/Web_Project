package com.test.neulbom.client.repository;

public class Mypage_Payment_UpdateDTO {
	private String pay_seq;
	private String resi_seq;
	private String ispay;
	private String pay_date;
	private String price;
}

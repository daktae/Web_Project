package com.test.neulbom.client.repository;

import lombok.Data;

@Data
public class UserDTO {

	private String id;
	private String lv;
	private String name;
	
}

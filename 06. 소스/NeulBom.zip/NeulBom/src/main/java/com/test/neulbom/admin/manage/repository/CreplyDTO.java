package com.test.neulbom.admin.manage.repository;

import lombok.Data;

@Data
public class CreplyDTO {
	
	String creply_seq;
	String title;
	String content;
	String cfile;
	String admin_seq;
	String con_seq;
	
	String replier;

}
